/*---------------------------------------------------------------------*/ ;
(function($) {
/*================= Global Variable Start =================*/
var isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
var IEbellow9 = !$.support.leadingWhitespace;
var iPhoneAndiPad = /iPhone|iPod/i.test(navigator.userAgent);
var isIE = navigator.userAgent.indexOf('MSIE') !== -1 || navigator.appVersion.indexOf('Trident/') > 0;
function isIEver() {var myNav = navigator.userAgent.toLowerCase();return (myNav.indexOf('msie') != -1) ? parseInt(myNav.split('msie')[1]) : false;}
//if (isIEver () == 8) {}
var ww = document.body.clientWidth,	wh = document.body.clientHeight; 
var mobilePort = 991, ipadView = 1024, wideScreen = 1600;
/*================= Global Variable End =================*/

/*================= On Document Load Start =================*/
$(document).ready(function() {
	
	
	
    getWidth();
    menuMove();
	
	

	

    if ($(".popular-slider").length) {
        var popularSlider = new Swiper(".popular-slider", {
          
          
            navigation: {
                nextEl: ".popular-button-next",
                prevEl: ".popular-button-prev",
            },
			 breakpoints: {
          320: {
            slidesPerView: 1,
            spaceBetween: 0,
          },
          576: {
            slidesPerView: 2,
            spaceBetween: 20,
          },
          1024: {
            slidesPerView: 3,
            spaceBetween: 25,
          },
		  1200: {
            slidesPerView: 3,
            spaceBetween: 55,
          },
		  }
        });
    }

    if ($(".contests-slider").length) {
        var contestsSlider = new Swiper(".contests-slider", {
		navigation: {
                nextEl: ".contests-button-next",
                prevEl: ".contests-button-prev",
            },
		breakpoints: {
          320: {
            slidesPerView: 1,
            spaceBetween: 0,
          },
          576: {
            slidesPerView: 2,
            spaceBetween: 20,
          },
          1024: {
            slidesPerView: 3,
            spaceBetween: 25,
          },
		  1200: {
            slidesPerView: 3,
            spaceBetween: 55,
          },
		  }
        });
    }

    if ($(".testimonials-slider").length) {
        var testimonialsSlider = new Swiper(".testimonials-slider", {
            slidesPerView: 1,
            spaceBetween: 55,
            navigation: {
                nextEl: ".testimonials-button-next",
                prevEl: ".testimonials-button-prev",
            },
        });
    }
	
	  if ($(".user-slider").length) {
        var testimonialsSlider = new Swiper(".user-slider", {
            slidesPerView: 1,
            spaceBetween: 55,
            navigation: {
                nextEl: ".user-button-next",
                prevEl: ".user-button-prev",
            },
        });
    }
	
	
	  if ($(".ready-slider").length) {
        var testimonialsSlider = new Swiper(".ready-slider", {
        
            navigation: {
                nextEl: ".ready-button-next",
                prevEl: ".ready-button-prev",
            },
			breakpoints: {
          320: {
            slidesPerView: 1,
            spaceBetween: 0,
          },
          576: {
            slidesPerView: 2,
            spaceBetween: 20,
          },
          1024: {
            slidesPerView: 3,
            spaceBetween:20,
          },
		  1200: {
            slidesPerView:4,
            spaceBetween:40,
          },
		  }
        });
    }

    if ($(".categories-slider").length) {
        var categoriesSlider = new Swiper(".categories-slider", {
           
           
            spaceBetween: 0,
            navigation: {
                nextEl: ".categories-button-next",
                prevEl: ".categories-button-prev",
            },
 breakpoints: {
          320: {
            slidesPerView: 1,
            slidesPerColumn: 2
          },
          576: {
            slidesPerView: 2,
            slidesPerColumn: 2
          },
          1024: {
            slidesPerView: 3,
            slidesPerColumn: 2
          },
		  1200: {
            slidesPerView: 5,
			slidesPerColumn: 2
          },
		  }
        });
    }

    if ($(".banner-slider").length) {
        var bannerSlider = new Swiper(".banner-slider", {
            loop:true,
			pagination: {
                el: ".swiper-pagination",
				clickable: true

            },
        });
    }
	
	
	if ($(".detailPageSliderWrap").length) {
	var detailPageSliderThumb = new Swiper(".detailPageSliderThumb .swiper-container", {
        spaceBetween: 0,
         slidesPerView:3,
        freeMode: true,
        watchSlidesVisibility: true,
        watchSlidesProgress: true,
		navigation: {
          nextEl: ".detailPageSliderThumb-next",
          prevEl: ".detailPageSliderThumb-prev",
        },
		breakpoints: {
          576: {
            slidesPerView:4,
           
          },
		 768: {
            slidesPerView: 2,
           
          },
          1024: {
            slidesPerView: 4,
           
          },
		  1200: {
            slidesPerView: 4,
			
           
          },
		  }
      });
      var detailPageSlider = new Swiper(".detailPageSlider .swiper-container", {
        spaceBetween: 0,
		effect: "fade",
		simulateTouch: false,
        thumbs: {
          swiper: detailPageSliderThumb,
        },
      });
	}
	
	
	//Expert Testimonials
	if ($(".expertTestimonials").length) {
        var expertTestimonials = new Swiper(".expertTestimonials .swiper-container", {
            pagination: {
                el: ".swiper-pagination",
				clickable: true
            },
			slidesPerView: 1,
			loop:true
        });
    }
	
	//Shorting Table
	if ($(".shortingTable").length) {
		var shortingTableheaders = $('.shortingTable thead th');
        $(shortingTableheaders[5]).attr('data-tablesort-type', 'date');
        $('.shortingTable').not(".tablesort").addClass('tablesort');
	}
	
	//Count down
	if ($(".contestLeftTime").length) {
		var d = new Date();
		simplyCountdown('contestLeftTime', {
			year: 2021,
			month: 10,
			day: 3
		});
	}


    //Inner pages banner bgimage
    if ($(".banner-slider").length) {
        $(".homeBannerImgWrap").each(function() {
            var imagePath = $(this).find("img").attr("src");
            $(this).css("background-image", "url( " + imagePath + " )");
        });
    }


	// Accordion
	if ($(".accordion").length) {
		$('.accordion .accordDetail').hide();
		$(".accordion .accordDetail:first").show();
		$(".accordion .accTrigger:first").addClass("active");
		$('.accordion .accTrigger').click(function() {
			if ($(this).hasClass('active')) {
				$(this).removeClass('active');
				$(this).next().slideUp();
			} else {
				if ($('body').hasClass('desktop')) {
					$('.accordion .accTrigger').removeClass('active');
					$('.accordion .accordDetail').slideUp();
				}
				$(this).addClass('active');
				$(this).next().slideDown();
			}
			return false;
		});
	};
	
	//On click sign up login modal hide
	$("#loginModal .signup-text a").click(function () {
		$("#loginModal").modal("hide");
		setTimeout(function(){ $("body").addClass("modal-open") }, 1000);
	});
	
	$("#registerModal .signin-text a").click(function () {
		$("#loginModal").modal("show");
		$("#registerModal").modal("hide");
		setTimeout(function(){ $("body").addClass("modal-open") }, 1000);
	});
	
	
	
	$("#partner-registerModal .greenBtn").click(function () {
		$("#partner-registerModal").modal("hide");
		setTimeout(function(){ $("body").addClass("modal-open") }, 1000);
	});
	
	
	$("#sendotpModal .send-otp").click(function () {
		$("#sendotpModal").modal("hide");
		setTimeout(function(){ $("body").addClass("modal-open") }, 1000);
	});

	
	//On scroll header fixed
	$(window).scroll(function(){
		if ($(window).scrollTop() >= 50) {
			$('#header').addClass('headerFixed');
		}
		else {
			$('#header').removeClass('headerFixed');
		}
	});
	if ($(window).scrollTop() >= 50) {
		$('#header').addClass('headerFixed');
	}
	else {
		$('#header').removeClass('headerFixed');
	}


    /*================= On Document Load and Resize Start =================*/
    $(window).on('resize', function() {

        ww = document.body.clientWidth;
        wh = document.body.clientHeight;

        if ($("body").hasClass("mobilePort")) {
            $("body").removeClass("wob");
        }

    }).trigger('resize');
    /*================= On Document Load and Resize End =================*/

    //Navigation
    if ($("#navMob").length) {
        if ($(".toggleMenu").length == 0) {
            $("#navbarNav").prepend('<div class="navbar-toggler"><a href="#" class="toggleMenu"><span class="iconBar"></span><span class="iconBar"></span><span class="iconBar"></span></a></div>');
        }
        $(".toggleMenu").click(function() {
            $(this).toggleClass("active");

            $("body").addClass("activeMobNav");
            return false;
        });
        $("#navMob li a").each(function() {
            if ($(this).next().length) {
                $(this).parent().addClass("parent");
            };
        })
        $("#navMob li.parent").each(function() {
            if ($(this).has(".menuIcon").length <= 0) $(this).append('<i class="menuIcon fa fa-angle-down"></i>')
        });
        dropdown('nav', 'hover', 1);
        adjustMenu();

    };
	
	// Responsive Tabing Script
	if ($(".resTab").length) {
		$('.resTab').responsiveTabs({
			rotate: false,
			startCollapsed: 'tab',
			collapsible: 'accordion',
			scrollToAccordion: true,
			scrollToAccordionOnLoad: false
		});
	};
	
	//Site search
	if ($(".search-wrapper").length) {
		$('.toggle-search').click(function(e) {
			e.preventDefault();
			if ($(".search-wrapper").hasClass('open')){
				$('.search-wrapper').removeClass('open');
			}else{
				$('.search-wrapper').addClass('open');
			} 
			return false;
		});
	
		$('.search-wrapper').click(function(e) {
			e.stopPropagation();
		});
		$(document).click(function() {
			$('.search-wrapper').removeClass('open');
		});
		$(".close-search").on("click", function(e){
			$(".search-wrapper").removeClass('open');
		});
	}
	
	
	//Event Mobile Filter
	if($(".eventFilterWrap").length) {
        $('.eventFilterWrap .filterAcc').click(function(e){
            e.preventDefault();
            if(!$(this).hasClass('active')){
                $(this).addClass('active');
                $(this).next().addClass('active');
            } else {
                $(this).removeClass('active');
                $(this).next().removeClass('active');
            }
            return false;
        });
    }

	// Back to Top function
	if ($("#backtotop").length) {
		$(window).scroll(function() {
			if ($(window).scrollTop() > 120) {
				$('#backtotop').fadeIn('250').css('display', 'block').addClass("active");
			} else {
				$('#backtotop').fadeOut('250').removeClass("active");
			}
		});
		$('#backtotop').click(function() {
			$('html, body').animate({
				scrollTop: 0
			}, '200');
			return false;
		});
	};
	
	//On click Comments section open 
	if ($(".comment-wrapper").length) {
		$('.toggle-comment').click(function(e) {
			e.preventDefault();
			if ($(".comment-wrapper").hasClass('open')){
				$('.comment-wrapper').removeClass('open');
			}else{
				$('.comment-wrapper').addClass('open');
			} 
			return false;
		});
	
		$('.comment-wrapper').click(function(e) {
			e.stopPropagation();
		});
		$(document).click(function() {
			$('.comment-wrapper').removeClass('open');
		});
		$(".close-comment").on("click", function(e){
			$(".comment-wrapper").removeClass('open');
		});
	}
	
	
	//On click dashboard sidebar section open 
	$('.vertical-menu-btn').click(function() {
   	$('body').toggleClass('sidebar-enable');
});
	
	//On click dashboard top menu open 
	$('.navbar-toggler-icon').click(function() {
   	$('body').toggleClass('topmenu-enable');
});




});
/*================= On Document Load End =================*/

/*================= On Window Resize Start =================*/
$(window).bind('resize orientationchange', function() {
    getWidth();
    adjustMenu();
    menuMove();
});

/*================= On Window Resize End =================*/


/*================= On Document Load End =================*/


function getWidth() {
    ww = document.body.clientWidth;
    if (ww > wideScreen) {
        $('body').removeClass('device').addClass('desktop widerDesktop');
    }
    if (ww > mobilePort && ww <= wideScreen) {
        $('body').removeClass('device widerDesktop').addClass('desktop');
    }
    if (ww <= mobilePort) {
        $('body').removeClass('desktop widerDesktop').addClass('device');
    }
    if (ww > 767 && ww < 1025) {
        $('body').addClass('ipad');
    } else {
        $('body').removeClass('ipad');
    }
    if (ww > 319 && ww < 768) {
        $('body').addClass('mobile');
    } else {
        $('body').removeClass('mobile');
    }
}

})(jQuery);


function validate() {
    return false;
};


function menuMove() {
    if ($(".mobileNav").length == 0) {
        var navigation = $('#navbar-nav').clone();
        $(navigation).appendTo("body").wrap("<div class='mobileNav'></div>");
        if ($(".mobileNav #navMob").length == 0) {
            $(".mobileNav #navbar-nav").attr("id", "navMob");
            $(".mobileNav").append("<span class='menuClose fa-times'></span>");
            $(".mobileNav").append("<span class='navigationText'>Menu</span>");
            //$(".mobileNav").append("<span class='logoText'><span class='logoIcon homeSprite'></span></span>");
            $(".mobileNav .menuClose").click(function() {
                $("body").removeClass("activeMobNav");
            });
        }
    }
}

	<!--select country code dropdown-->
	$('.select-country').flagStrap({
	countries: {
		"CA": "+1",
		"AU": "+672",
		"FR": "+33",
		"BR": "+55",
		"IN": "+91",
		"BS": "+1 242"
	},
	
	buttonType: "btn-code",
	labelMargin: "10px",
	scrollable: false,
	scrollableHeight: "350px"
});

<!--select country code-->

new SimpleBar(document.getElementById('demo'))